#!/bin/sh
module use /opt/insy/modulefiles
module load cuda/11.6
make
#./acsmatmult -t
./acsmatmult -v -y 11 -r 2
./acsmatmult -m -y 11 -r 2
#./acsmatmult -s -y 11 -r 2
#./acsmatmult -o 2 -y 11 -r 2
#./acsmatmult -o 4 -y 11 -r 2
#./acsmatmult -o 8 -y 11 -r 2
#./acsmatmult -c -y 12 -r 2
